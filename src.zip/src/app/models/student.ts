export interface Students {
    Id: number;
    Name: string;
    Courses: string;
    Class: string;
    ContactNumber: string;
    MarkedCourseIds:string;
    ClassId: string;
  }
  